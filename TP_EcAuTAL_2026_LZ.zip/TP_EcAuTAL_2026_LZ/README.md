# EcAuTAL 2026 
# Exploration d'un corpus clinique : un cas d'étude du projet PARTAGES

## Organisation du dossier

```
TP_EcAUTAL_2026_LZ/
├── data/                          # Corpus de 20 documents cliniques
│   ├── MANIFEST.json              # Métadonnées et liste des documents
│   └── [20 documents × 6 variantes chacun]
├── logos/                         # Images pour le notebook
├── requirements.txt               # Dépendances Python
├── ecautal_CU3_PARTAGES_practical_notebook.ipynb   # Notebook principal
└── README.md                      # Ce fichier
```

### Contenu de data/

Le dossier `data/` contient **20 comptes rendus cliniques** provenant de différentes spécialités médicales (cardiologie, chirurgie, gynécologie, etc.).

Pour chaque document, vous trouverez **6 variantes**:

| Variante | Fichier | Description |
|----------|---------|-------------|
| **Complet** | `{doc}_full.txt` | Le document original intégral |
| **Corps** | `{doc}_CR.txt` | Le corps du compte rendu (avant la section "Conclusion") |
| **Annotation A** | `{doc}_conclusion_A.txt` | Résumé annoté par l'annotateur A |
| **Annotation T** | `{doc}_conclusion_T.txt` | Résumé annoté par l'annotateur T |
| **Gold Standard** | `{doc}_conclusion_GS.txt` | Résumé de référence (consensus des deux annotateurs) |
| **Mistral** | `{doc}_conclusion_mistral.txt` | Résumé généré par le modèle Mistral |

### Exemple

Pour le document `CANCERO-ADULTE-00179_CRH`, vous trouverez:
- `CANCERO-ADULTE-00179_CRH_full.txt` : le CR complet
- `CANCERO-ADULTE-00179_CRH_CR.txt` : le corps du CR
- `CANCERO-ADULTE-00179_CRH_conclusion_A.txt` : résumé de l'annotateur A
- `CANCERO-ADULTE-00179_CRH_conclusion_T.txt` : résumé de l'annotateur T
- `CANCERO-ADULTE-00179_CRH_conclusion_GS.txt` : résumé Gold Standard
- `CANCERO-ADULTE-00179_CRH_conclusion_mistral.txt` : résumé généré


### Sélection des documents

Les 20 documents ont été sélectionnés parmi les cas où les deux annotateurs **divergent** (accord lexical < 100%). Cela nous permet d'explorer:
- Les défis de l'annotation
- Les sources de désaccord entre annotateurs
- L'impact du consensus sur la qualité de la référence
